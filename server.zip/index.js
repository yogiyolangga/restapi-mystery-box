const express = require("express");
const bodyParser = require('body-parser');
const cors = require('cors')
const app = express();
const mysql = require("mysql");

const cookieParser = require("cookie-parser");
const session = require("express-session");

const db = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "",
    database: "fortuneslot88",
});

app.use(cors({
    origin: ["http://localhost:3000", "http://localhost:3002"],
    methods: ["GET", "POST", "DELETE", "PUT"],
    credentials: true
}));

app.use(cookieParser())
app.use(express.json());
app.use(bodyParser.urlencoded({extended: true}));

app.use(session({
    key: "userId",
    secret: "fortuneslot88",
    resave: false,
    saveUninitialized: false,
    cookie: {
        expires: 60 * 60 * 24
    },
}));

app.get("/", (req, res) => {
    const sqlSelect = "SELECT * FROM datatiket";
    db.query(sqlSelect, (err, result) => {
        res.send("Mystery Box Fortune Slot 88 API Server");
    });
});

app.get("/api/get", (req, res)=> {
    const sqlSelect = "SELECT * FROM datatiket ORDER BY tanggal DESC";
    db.query(sqlSelect, (err, result)=> {
        res.send(result);
    });
});

app.post("/api/daterange", (req, res)=> {
    const startDate = req.body.startDate;
    const endDate = req.body.endDate;
    const sqlSelect = "SELECT * FROM datatiket WHERE tanggal >= ? AND tanggal <= ?";
    db.query(sqlSelect, [startDate, endDate], (err, result)=> {
        res.send(result);
    });
});

app.get("/api/gettoday/:tanggal", (req, res)=> {
    const tanggal = req.params.tanggal;
    
    const sqlSelect = "SELECT * FROM datatiket WHERE tanggal = ? ORDER BY id DESC";
    db.query(sqlSelect, [tanggal], (err, result)=> {
        res.send(result);
    });
});

app.get("/login", (req, res) => {
    if(req.session.user) {
        res.send({ loggedIn: true, user: req.session.user });
    } else {
        res.send({ loggedIn: false});
    }
});

app.post("/logout", (req, res) => {
    req.session.destroy();
    res.send({loggedIn: false});
})

app.post('/login', (req, res) => {
    const username = req.body.username;
    const kode = req.body.kode;

    db.query(
        "SELECT * FROM datatiket WHERE username = ? AND kode = ?",
        [username, kode],
        (err, result) => {
            if (err) {
            res.send({err: err});
            }
           
            if (result.length > 0) {
                req.session.user = result;
                console.log(req.session.user);
                res.send(result);
            } else {
                res.send({message: "Maaf, Username atau Tiket Salah!"})
            }
        }
    );
});

app.post("/api/insert", (req, res) => {

    const username = req.body.username;
    const kode = req.body.kode;
    const hadiah = req.body.hadiah;
    const tanggal = req.body.tanggal;

    const sqlInsert = "INSERT INTO datatiket (tanggal, username, kode, hadiah, chance) VALUES (?,?,?,?,?)";
    const check = "SELECT * FROM datatiket WHERE kode = ?";

    db.query(check, [kode], (err, result) => {
        if (err) {
            res.send({err: err});
        }

        if (username === "") {
            res.send({message: "Username Tidak Boleh Kosong!"});
        } else if (kode === "") {
            res.send({message: "Kode Tidak Boleh Kosong!"});
        } else if (hadiah === "") {
            res.send({message: "Pilih Hadiah!"});
        } else if (result.length > 0) {
            res.send({message: "Maaf, Tiket sudah ada! Generate Ulang!"});
        } else {
            db.query(sqlInsert, [tanggal, username, kode, hadiah, 1], (err, result)=> {
                console.log(result);
                res.send(result);
            });
        }
    })
})

app.delete("/api/delete/:id", (req, res) => {
    const id = req.params.id;
    const sqlDelete = "DELETE FROM datatiket WHERE id = ?";

    db.query(sqlDelete, id, (err, result) => {
        if (err) console.log(err);
    });
});

app.delete("/api/deletenew/:kode", (req, res) => {
    const kode = req.params.kode;
    const sqlDelete = "DELETE FROM datatiket WHERE kode = ?";

    db.query(sqlDelete, kode, (err, result) => {
        if (err) console.log(err);
    });
});

app.put("/api/update/:id", (req, res) => {
    const id = req.params.id;
    const sqlUpdate = "UPDATE datatiket SET chance = 0 WHERE id = ?";

    db.query(sqlUpdate, id, (err, result) => {
        if (err) console.log(err);
    });
});

app.listen(3001, () => {
    console.log("listening on port 3001");
});